package OrangeHRM_Automation;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class OrangeHRM_Automation {
	
	WebDriver driver;
	
	
	@BeforeTest
	public void lauchURL() {
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver_win32\\chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
		
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	
	@Test(priority=1)
	public void Testcase1() throws InterruptedException {
		
		driver.findElement(By.xpath("//input[@id='txtUsername']")).clear();
		driver.findElement(By.xpath("//input[@id='txtUsername']")).sendKeys("Admin");
		
		driver.findElement(By.xpath("//input[@id='txtPassword']")).clear();
		driver.findElement(By.xpath("//input[@id='txtPassword']")).sendKeys("admin123");
		String URL=driver.getCurrentUrl();
		String Title = driver.getTitle();
		
		System.out.println(URL);
		
		
		Assert.assertTrue(driver.getTitle().contains("OrangeHRM"));
		
		driver.findElement(By.xpath("//input[@id='btnLogin']")).click();
	}
	
	@Test(priority=2)
	public void Testcase2() throws InterruptedException  {
		
		/*Appoach 1 to validate one by One
		List<WebElement> Quicklinks = driver.findElements(By.xpath("//span[conains(@class,'quickLinkText')]"));
		
		for(int i=0; i<Quicklinks.size(); i++) {
			if(Quicklinks.get(i).getText().contains("Timesheets")) {
				Quicklinks.get(i).click();
			}
		} */
		
		// Assign Leave
		boolean AssignLeaveLink = driver.findElement(By.xpath("//span[contains(text(),'Assign Leave')]")).isEnabled();
		Assert.assertTrue(true, "Assign Leave link is not enabled");
		
		driver.findElement(By.xpath("//span[contains(text(),'Assign Leave')]")).click();
		
		Thread.sleep(2000);
		boolean Verifybutton=driver.findElement(By.xpath("//input[contains(@id,'assignBtn')]")).isDisplayed();
		Assert.assertTrue(true, "Button is not dissplyed");
		System.out.println("Assign Leave link is working");
		driver.navigate().back();
		
		
		//Leave List
		boolean leaveListLink = driver.findElement(By.xpath("//span[contains(text(),'Leave List')]")).isEnabled();
		Assert.assertTrue(true, "Leave List link is not enabled");
		
		driver.findElement(By.xpath("//span[contains(text(),'Leave List')]")).click();
		
		Thread.sleep(2000);
		boolean VerifySearchbutton=driver.findElement(By.xpath("//input[contains(@id,'btnSearch')]")).isDisplayed();
		Assert.assertTrue(true, "Button is not dissplyed");
		System.out.println("Leave list link is working");
		driver.navigate().back();
		
		//TimeSheet
		boolean TimeSheetLink = driver.findElement(By.xpath("//span[contains(text(),'Timesheets')]")).isEnabled();
		Assert.assertTrue(true, "TimeSheet link is not enabled");
		
		driver.findElement(By.xpath("//span[contains(text(),'Timesheets')]")).click();
		
		Thread.sleep(2000);
		boolean VerifyViewbutton=driver.findElement(By.xpath("//input[contains(@id,'btnView')]")).isDisplayed();
		Assert.assertTrue(true, "Button is not dissplyed");
		System.out.println("TimeSheet link is working");
		driver.navigate().back();
		
		//Apply Leave
		boolean applyLeaveLink = driver.findElement(By.xpath("//span[contains(text(),'Apply Leave')]")).isEnabled();
		Assert.assertTrue(true, "Apply Leave link is not enabled");
		
		driver.findElement(By.xpath("//span[contains(text(),'Apply Leave')]")).click();
		
		Thread.sleep(2000);
		boolean VerifyApplybutton=driver.findElement(By.xpath("//input[contains(@id,'applyBtn')]")).isDisplayed();
		Assert.assertTrue(true, "Button is not dissplyed");
		System.out.println("Apply Leave link is working");
		driver.navigate().back();
		
		//My Leave
		boolean myLeaveLink = driver.findElement(By.xpath("//span[contains(text(),'My Leave')]")).isEnabled();
		Assert.assertTrue(true, "My Leave link is not enabled");
		
		driver.findElement(By.xpath("//span[contains(text(),'My Leave')]")).click();
		
		Thread.sleep(2000);
		boolean Verifysearchbutton=driver.findElement(By.xpath("//input[contains(@id,'btnSearch')]")).isDisplayed();
		Assert.assertTrue(true, "Button is not dissplyed");
		System.out.println("My Leave link is working");
		driver.navigate().back();
		
		
		//My TimeSheet
		driver.findElement(By.xpath("//span[contains(text(),'My Timesheet')]")).click();
		
		Thread.sleep(2000);
		boolean VerifyAddTSLink=driver.findElement(By.xpath("//input[contains(@id,'btnEdit')]")).isDisplayed();
		Assert.assertTrue(true, "Add TimeSheet link is not dissplyed");
		System.out.println("My TimeSheet link is working");
		driver.navigate().back();
	}
		
	@Test(priority=3)
	public void Testcase3() {
		
		//driver.findElement(By.xpath("//input[@id='imagesrc']")).sendKeys("C:\\Users\\Mukhim\\Desktop\\AppiumTest.txt");
		WebElement t = driver.findElement(By.className("legendColorBox"));
	      //obtain color in rgba
	      String s = t.getCssValue("color");
	      // convert rgba to hex
	      String c = Color.fromString(s).asHex();
	      System.out.println("Color is :" + s);
	      System.out.println("Hex code for color:" + c);
	}	
		
	
		
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
		
		
		
	}


